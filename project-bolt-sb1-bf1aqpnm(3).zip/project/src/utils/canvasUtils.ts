import { School } from 'lucide-react';
import { renderToString } from 'react-dom/server';

/**
 * Generate a framed photo with IFNTI branding and user information
 */
export const generateFramedPhoto = (
  canvas: HTMLCanvasElement,
  photoDataUrl: string,
  firstName: string,
  lastName: string,
  dateString: string
): Promise<string> => {
  return new Promise((resolve, reject) => {
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      reject(new Error('Canvas context not available'));
      return;
    }

    // Load the photo
    const photo = new Image();
    photo.onload = () => {
      try {
        // Set canvas dimensions (square format)
        const size = 1080; // HD size for social media
        canvas.width = size;
        canvas.height = size;
        
        // IFNTI Colors (exact from specifications)
        const ifntiBlue = '#0052CC';
        const ifntiOrange = '#F26A1B';
        const ifntiGrey = '#666666';
        const white = '#FFFFFF';
        
        // Fill background with white
        ctx.fillStyle = white;
        ctx.fillRect(0, 0, size, size);
        
        // Draw orange corner shape
        ctx.fillStyle = ifntiOrange;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(size * 0.6, 0);
        ctx.lineTo(0, size * 0.6);
        ctx.closePath();
        ctx.fill();

        // Add dots pattern in orange area
        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        const dotSpacing = 40;
        for (let x = dotSpacing; x < size * 0.5; x += dotSpacing) {
          for (let y = dotSpacing; y < size * 0.5; y += dotSpacing) {
            if (x < y) {
              ctx.beginPath();
              ctx.arc(x, y, 3, 0, Math.PI * 2);
              ctx.fill();
            }
          }
        }

        // Draw blue diagonal stripes
        ctx.fillStyle = ifntiBlue;
        const stripeWidth = size * 0.15;
        const stripeSpacing = size * 0.1;
        
        // First blue stripe
        ctx.beginPath();
        ctx.moveTo(size * 0.5, size);
        ctx.lineTo(size, size * 0.5);
        ctx.lineTo(size, size * 0.5 + stripeWidth);
        ctx.lineTo(size * 0.5 + stripeWidth, size);
        ctx.closePath();
        ctx.fill();

        // Second blue stripe
        ctx.beginPath();
        ctx.moveTo(size * 0.7, size);
        ctx.lineTo(size, size * 0.7);
        ctx.lineTo(size, size * 0.7 + stripeWidth);
        ctx.lineTo(size * 0.7 + stripeWidth, size);
        ctx.closePath();
        ctx.fill();

        // Draw orange diagonal stripe
        ctx.fillStyle = ifntiOrange;
        ctx.beginPath();
        ctx.moveTo(size * 0.6, size);
        ctx.lineTo(size, size * 0.6);
        ctx.lineTo(size, size * 0.6 + stripeWidth);
        ctx.lineTo(size * 0.6 + stripeWidth, size);
        ctx.closePath();
        ctx.fill();

        // Calculate photo placement (centered with margins)
        const photoMargin = size * 0.15;
        const photoSize = size - (photoMargin * 2);
        
        // Draw photo
        ctx.save();
        ctx.beginPath();
        ctx.rect(photoMargin, photoMargin, photoSize, photoSize);
        ctx.clip();
        ctx.drawImage(photo, photoMargin, photoMargin, photoSize, photoSize);
        ctx.restore();
        
        // Add white overlay for text
        const textAreaHeight = size * 0.25;
        const textY = size - textAreaHeight;
        
        ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
        ctx.fillRect(0, textY, size, textAreaHeight);
        
        // Draw "JOURNÉE PORTES OUVERTES"
        ctx.fillStyle = ifntiBlue;
        ctx.font = `bold ${size * 0.06}px Montserrat, Arial`;
        ctx.textAlign = 'center';
        ctx.fillText('JOURNÉE', size / 2, textY + size * 0.08);
        ctx.font = `bold ${size * 0.07}px Montserrat, Arial`;
        ctx.fillText('PORTES OUVERTES', size / 2, textY + size * 0.16);
        
        // Draw names
        ctx.font = `bold ${size * 0.045}px "Open Sans", Arial`;
        ctx.fillStyle = ifntiBlue;
        ctx.fillText(`${firstName} ${lastName}`, size / 2, textY + size * 0.22);
        
        // Draw date
        ctx.font = `${size * 0.035}px "Open Sans", Arial`;
        ctx.fillStyle = ifntiOrange;
        ctx.fillText(dateString, size / 2, textY + size * 0.19);
        
        // Return the final image
        resolve(canvas.toDataURL('image/png'));
      } catch (error) {
        reject(error);
      }
    };
    
    photo.onerror = () => {
      reject(new Error('Failed to load photo'));
    };
    
    photo.src = photoDataUrl;
  });
};