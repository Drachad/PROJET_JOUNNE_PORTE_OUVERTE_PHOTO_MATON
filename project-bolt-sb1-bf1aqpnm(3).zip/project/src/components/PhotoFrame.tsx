import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Download, School } from 'lucide-react';
import { formatDate } from '../utils/dateUtils';
import { generateFramedPhoto } from '../utils/canvasUtils';
import { removeBackground } from '@imgly/background-removal';

interface PhotoFrameProps {
  userData: {
    firstName: string;
    lastName: string;
  };
  photoData: string;
  onGenerated: (imageDataUrl: string) => void;
  onBack: () => void;
}

const PhotoFrame: React.FC<PhotoFrameProps> = ({
  userData,
  photoData,
  onGenerated,
  onBack,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [previewImageUrl, setPreviewImageUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const processImage = async () => {
      if (!photoData) return;
      
      setIsProcessing(true);
      try {
        // Remove background from the photo
        const processedImage = await removeBackground(photoData);
        
        // Generate the final composition with the processed image
        if (canvasRef.current) {
          const imageUrl = await generateFramedPhoto(
            canvasRef.current,
            processedImage,
            userData.firstName,
            userData.lastName,
            formatDate(new Date())
          );
          
          setPreviewImageUrl(imageUrl);
        }
      } catch (error) {
        console.error('Error processing image:', error);
      } finally {
        setIsProcessing(false);
      }
    };

    processImage();
  }, [photoData, userData]);

  const handleGenerate = async () => {
    if (!canvasRef.current || !previewImageUrl) return;
    
    setIsGenerating(true);
    
    try {
      // We already have the preview image, so we can just pass it to the parent
      onGenerated(previewImageUrl);
    } catch (error) {
      console.error('Error generating final image:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden transition-all">
      {/* Back button */}
      <div className="p-4 bg-gray-50 border-b">
        <button 
          onClick={onBack} 
          className="flex items-center text-[#666666] hover:text-[#0052CC]"
        >
          <ArrowLeft size={16} className="mr-1" />
          <span>Retour à la capture</span>
        </button>
      </div>

      {/* Content */}
      <div className="p-6">
        <h2 className="text-xl font-bold text-center mb-6 text-[#0052CC]">Prévisualisation</h2>
        
        <div className="border border-[#666666] border-opacity-20 rounded-lg overflow-hidden mb-6">
          <canvas ref={canvasRef} className="w-full h-auto hidden" />
          
          {isProcessing ? (
            <div className="bg-gray-100 p-8 flex items-center justify-center">
              <p className="text-[#666666]">Traitement de l'image en cours...</p>
            </div>
          ) : previewImageUrl ? (
            <img 
              src={previewImageUrl} 
              alt="Prévisualisation" 
              className="w-full h-auto"
            />
          ) : (
            <div className="bg-gray-100 p-8 flex items-center justify-center">
              <p className="text-[#666666]">Génération de la prévisualisation...</p>
            </div>
          )}
        </div>
        
        <button
          onClick={handleGenerate}
          disabled={!previewImageUrl || isGenerating}
          className={`w-full py-3 rounded-full flex items-center justify-center ${
            !previewImageUrl || isGenerating
              ? 'bg-[#666666] text-white cursor-not-allowed'
              : 'bg-[#0052CC] text-white hover:bg-[#0052CC]/90'
          } transition-colors`}
        >
          <Download size={18} className="mr-2" />
          {isGenerating ? 'Génération en cours...' : 'Continuer vers le téléchargement'}
        </button>
      </div>
    </div>
  );
};

export default PhotoFrame;