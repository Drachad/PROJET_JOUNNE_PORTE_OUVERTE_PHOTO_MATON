/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ifnti: {
          blue: '#0052CC',
          orange: '#F26A1B',
          grey: '#666666',
        },
      },
    },
  },
  plugins: [],
};